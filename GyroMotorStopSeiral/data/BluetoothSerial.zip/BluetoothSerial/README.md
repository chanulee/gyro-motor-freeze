### Bluetooth Serial Library

A simple Serial compatible library using ESP32 classical bluetooth (SPP)



#### How to use it?

- Download one bluetooth terminal app in your smartphone<br>
For Android: https://play.google.com/store/apps/details?id=de.kai_morich.serial_bluetooth_terminal <br>
For iOS: https://itunes.apple.com/us/app/hm10-bluetooth-serial-lite/id1030454675

- Flash an example sketch to your ESP32

- Scan and pair the device in your smartphone

- Open the bluetooth terminal app

- Enjoy
